
from .string_ops import reverse_string, count_vowels, capitalize_words

def hello():
    return "Bonjour depuis le package_creation_tutorial !"

