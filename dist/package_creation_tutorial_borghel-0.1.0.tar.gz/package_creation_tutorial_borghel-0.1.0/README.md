1. Clonez le dépôt :
   ```bash
   git clone https://github.com/borghel/package_creation_tutorial.git sous windows


**Après :**
```markdown
1. Clonez le dépôt sous Windows :
   ```bash
   git clone https://github.com/borghel/package_creation_tutorial.git


4. Enregistrez les modifications.

---

### Étape 2 : Commit et mise à jour sur GitHub
1. Ouvrez un terminal ou une invite de commandes et naviguez dans le dossier de votre dépôt local :
   ```bash
   cd chemin/vers/package_creation_tutorial

Commitez et poussez le fichier :
```bash
git add README.md
git commit -m "Ajout du fichier README.md"
git push
3. Ajouter d'autres fichiers ou scripts
Créez des modules ou scripts pour la logique principale de votre projet Python.
Ajoutez un fichier setup.py si vous envisagez de rendre ce projet installable comme package Python.
Exemple de base pour setup.py :